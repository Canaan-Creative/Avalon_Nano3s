cd /sharefs
./rtt_decrypt asic_miner_e asic_miner &
